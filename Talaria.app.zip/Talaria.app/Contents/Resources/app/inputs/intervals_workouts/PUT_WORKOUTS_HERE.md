# Workouts

Put any Intervals.icu workout `.txt` files here.

Use filenames like:

```text
2027-03-14_easy-bike-45m.txt
2027-03-15_swim-technique.txt
2027-03-16_strength-upper-body.txt
2027-03-17_yoga-mobility.txt
```

The app infers the workout type from the filename, title, and workout text.
