Completed training and recovery summary for 2026-02-03 to 2026-06-24
Use this as context for conservative coaching decisions. Prioritise completed work, recent load, HR response, sleep/recovery, injury risk, and whether the next 7 days should be progressed, held, or reduced.

Completed activities by sport:
- OpenWaterSwim: 4 sessions, 2h 1m, load 102, distance 5.0km, energy 1013
- Ride: 13 sessions, 23h 12m, load 1215, distance 464.3km, elevation 5705m, energy 10985
- Run: 40 sessions, 32h 1m, load 1546, distance 236.8km, elevation 1492m, energy 15671
- Swim: 31 sessions, 17h 30m, load 1089, distance 40.1km, energy 11406
- VirtualRide: 9 sessions, 8h 30m, load 487, distance 204.3km, elevation 799m, energy 3763

Recent activity detail:
- 2026-06-23: Run - Pembrokeshire - W15 Tue Run - 60m with 15m Z4; 58m; load 63; distance 8.5km; elevation 43m; avg HR 158bpm; max HR 192bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 2.43m/s; pace 2.45m/s; GAP 2.34m/s; cadence 76rpm; feel 1; session RPE 461; intensity 80.56; TRIMP 104; HR load 63; polarization 2.5; stride 0.97m; workout compliance 94%; HR zones: Z1 26m, Z2 15m, Z3 2m, Z4 40s, Z5 2m, Z6 11m, Z7 29s
  HR load model: type HRSS, HR load 64, training data points 100
  time at HR: min 98bpm, max 192bpm, largest HR bucket 4m, cumulative high-HR tail 58m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 54bpm
  weather: rain 0mm
- 2026-06-21: Run - Carmarthenshire Running; 29m; load 32; distance 5.0km; elevation 8m; avg HR 160bpm; max HR 176bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 2.85m/s; pace 2.86m/s; GAP 2.8m/s; cadence 79rpm; intensity 81.07; TRIMP 54; HR load 32; polarization 0; stride 1.08m; workout compliance 0%; HR zones: Z1 3m, Z2 8m, Z3 14m, Z4 3m
  HR load model: type HRSS, HR load 32, training data points 100
  time at HR: min 121bpm, max 176bpm, largest HR bucket 3m, cumulative high-HR tail 29m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 39bpm
  weather: rain 0mm
- 2026-06-21: Ride - Carmarthenshire Road Cycling; 2h 47m; load 195; distance 58.3km; elevation 794m; avg HR 153bpm; max HR 185bpm; athlete max HR setting 200bpm; LTHR 175bpm; FTP 180w; avg speed 4.41m/s; pace 5.81m/s; intensity 73.01; TRIMP 250; HR load 195; polarization 1.06; workout compliance 0%; HR zones: Z1 24m, Z2 50m, Z3 24m, Z4 49m, Z5 16m, Z6 3m, Z7 3s
  HR load model: type HRSS, HR load 195, training data points 100
  time at HR: min 108bpm, max 185bpm, largest HR bucket 7m, cumulative high-HR tail 2h 46m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 75bpm
  weather: rain 0mm
- 2026-06-21: OpenWaterSwim - Carmarthenshire Open Water Swimming; 34m; load 43; distance 1.6km; avg HR 167bpm; max HR 178bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 0.75m/s; pace 0.75m/s; cadence 29rpm; intensity 86.29; TRIMP 75; HR load 43; pace load 42; polarization 0; stride 0.76m; HR zones: Z1 2m, Z2 2m, Z3 19m, Z4 12m
  HR load model: type HRSS, HR load 43, training data points 100
  time at HR: min 120bpm, max 178bpm, largest HR bucket 5m, cumulative high-HR tail 35m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 173bpm
  weather: rain 0mm
- 2026-06-20: VirtualRide - B60m(8x3mZ4Hills); 59m; load 90; distance 13.9km; elevation 373m; avg HR 141bpm; max HR 173bpm; athlete max HR setting 200bpm; LTHR 175bpm; avg power 128w; weighted power 172w; FTP 180w; avg speed 3.84m/s; pace 3.91m/s; cadence 0rpm; intensity 95.56; TRIMP 66; power load 90; HR load 48; decoupling -3.9%; efficiency factor 1.22; variability index 1.34; polarization 2; strain 100.9; power/HR 0.91; Z2 power/HR 1; Z2 cadence 0rpm; work above FTP 50406J; max W' depletion 12656J; carbs used 195g; workout compliance 138%; HR zones: Z1 33m, Z2 10m, Z3 2m, Z4 14m; power zones: Z1 20m, Z2 15m, Z3 4m, Z4 6m, Z5 6m, Z6 8m, Z7 2m, SS 4m
  HR load model: type HRSS, HR load 48, training data points 100
  time at HR: min 89bpm, max 173bpm, largest HR bucket 4m, cumulative high-HR tail 59m
  power-vs-HR: decoupling -3.9%, power/HR 0.88, first half power/HR 0.86, second half power/HR 0.9, Z2 power/HR 1, Z2 cadence 0rpm, Z2 buckets 5
  best efforts: best 5m HR 152bpm, best 5m power 178w, best 20m power 136w
  weather: rain 0mm
- 2026-06-18: Run - Swansea - R60m4x6mZ4; 60m; load 74; distance 8.9km; elevation 49m; avg HR 162bpm; max HR 196bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 2.46m/s; pace 2.48m/s; GAP 2.38m/s; cadence 73rpm; feel 1; session RPE 536; intensity 85.66; TRIMP 121; HR load 74; polarization 1.91; stride 1.02m; workout compliance 110%; HR zones: Z1 23m, Z2 7m, Z3 6m, Z4 5m, Z5 3m, Z6 8m, Z7 8m
  HR load model: type HRSS, HR load 74, training data points 100
  time at HR: min 84bpm, max 196bpm, largest HR bucket 2m, cumulative high-HR tail 60m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 73bpm
  weather: rain 0mm
- 2026-06-18: Swim - Pool Swim; 48m; load 21; distance 391m; avg HR 119bpm; max HR 173bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 0.98m/s; pace 0.14m/s; cadence 21rpm; intensity 51.32; TRIMP 33; HR load 21; pace load 0; polarization 0; stride 0.2m; swim lengths 17; pool 23m; HR zones: Z1 42m, Z2 3m, Z3 2m, Z4 17s
  HR load model: type HRSS, HR load 21, training data points 100
  time at HR: min 69bpm, max 173bpm, largest HR bucket 3m, cumulative high-HR tail 48m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 158bpm
  weather: rain 0mm
- 2026-06-16: VirtualRide - B45minZ2; 60m; load 49; distance 28.3km; avg HR 141bpm; max HR 151bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg power 125w; weighted power 126w; FTP 180w; avg speed 7.85m/s; pace 7.85m/s; cadence 0rpm; intensity 70; TRIMP 74; power load 49; HR load 41; decoupling -2%; efficiency factor 0.89; variability index 1.01; polarization 0.19; strain 66.6; power/HR 0.89; work above FTP 180J; max W' depletion 127J; carbs used 77g; workout compliance 114%; HR zones: Z1 54m, Z2 6m; power zones: Z1 42s, Z2 56m, Z3 3m, Z4 9s, Z5 3s, SS 32s
  HR load model: type HRSS, HR load 41, training data points 100
  time at HR: min 84bpm, max 151bpm, largest HR bucket 11m, cumulative high-HR tail 60m
  power-vs-HR: decoupling -2%, power/HR 0.89, first half power/HR 0.88, second half power/HR 0.9, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 144bpm, best 5m power 134w, best 20m power 128w
  weather: rain 0mm
- 2026-06-16: Swim - Pool Swim; 34m; load 38; distance 1.5km; avg HR 153bpm; max HR 182bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 0.75m/s; pace 0.75m/s; cadence 24rpm; intensity 65.69; TRIMP 56; HR load 38; pace load 42; polarization -0.45; stride 0.95m; swim lengths 61; pool 25m; HR zones: Z1 10m, Z2 2m, Z3 10m, Z4 12m, Z5 13s
  HR load model: type HRSS, HR load 38, training data points 100
  time at HR: min 101bpm, max 182bpm, largest HR bucket 3m, cumulative high-HR tail 34m
  power-vs-HR: power/HR 0, first half power/HR 0, second half power/HR 0, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 173bpm
  weather: rain 0mm
- 2026-06-15: VirtualRide - B2hrZ2; 1h 51m; load 82; distance 51.3km; avg HR 131bpm; max HR 145bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg power 118w; weighted power 120w; FTP 180w; avg speed 7.68m/s; pace 7.69m/s; cadence 0rpm; intensity 66.67; TRIMP 101; power load 82; HR load 57; decoupling 2.6%; efficiency factor 0.92; variability index 1.02; polarization 0; strain 112.3; power/HR 0.9; work above FTP 152J; max W' depletion 108J; carbs used 179g; workout compliance 95%; HR zones: Z1 1h 51m, Z2 1s; power zones: Z1 2m, Z2 1h 44m, Z3 4m, Z4 24s, SS 69s
  HR load model: type HRSS, HR load 57, training data points 100
  time at HR: min 84bpm, max 145bpm, largest HR bucket 11m, cumulative high-HR tail 1h 51m
  power-vs-HR: decoupling 2.6%, power/HR 0.9, first half power/HR 0.91, second half power/HR 0.89, Z2 power/HR 0, Z2 cadence 0rpm, Z2 buckets 0
  best efforts: best 5m HR 138bpm, best 5m power 136w, best 20m power 119w
  weather: rain 0mm
- 2026-06-14: OpenWaterSwim - Carmarthenshire Open Water Swimming; 9m; load 8; distance 303m; avg HR 151bpm; max HR 180bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 0.52m/s; pace 0.54m/s; cadence 27rpm; TRIMP 14; HR load 8; pace load 4; polarization 0.89; stride 0.59m; HR zones: Z1 6m, Z2 2m, Z3 41s, Z4 36s, Z5 7s
- 2026-06-14: OpenWaterSwim - Carmarthenshire Open Water Swimming; 44m; load 30; distance 1.8km; avg HR 137bpm; max HR 178bpm; athlete max HR setting 198bpm; LTHR 180bpm; avg speed 0.65m/s; pace 0.68m/s; cadence 27rpm; intensity 62.43; TRIMP 47; HR load 30; pace load 40; polarization 0; stride 0.75m; HR zones: Z1 31m, Z2 2m, Z3 10m, Z4 79s

Latest wellness/recovery (2026-06-24): fitness/CTL 48.7, acute load/ATL 66.1, ramp rate 4.4
Wellness range averages: avg HRV 45.8ms, avg resting HR 59bpm, avg sleep 6.8h, avg sleep score 76

Recent wellness/recovery detail:
- 2026-06-18: HRV 59ms, RHR 54bpm, sleep 6h 16m, sleep score 77
- 2026-06-19: HRV 38ms, RHR 61bpm, sleep 6h 29m, sleep score 73
- 2026-06-20: HRV 36ms, RHR 61bpm, sleep 6h 28m, sleep score 71
- 2026-06-21: HRV 40ms, RHR 62bpm, sleep 6h 16m, sleep score 73
- 2026-06-22: HRV 30ms, RHR 62bpm, sleep 4h 40m, sleep score 48
- 2026-06-23: HRV 50ms, RHR 58bpm, sleep 6h 30m, sleep score 78

Additional latest wellness fields from Intervals.icu:
- ctlLoad: 0.0; atlLoad: 0.0; sportInfo: [{'type': 'Ride', 'eftp': 153.0, 'wPrime': 11376.0, 'pMax': 383.0}]; updated: 2026-06-23T19:04:30.764+00:00; tempWeight: False; tempRestingHR: False

Prompt for an AI coach:
Given the completed training, HR response, intensity distribution, best-effort context, fitness/load trend, and recovery data above, identify fatigue risk, likely limiters, signs of improving or worsening fitness, and the most sensible changes for the next 7 days. Keep recommendations conservative, flag missing data, and explain assumptions.