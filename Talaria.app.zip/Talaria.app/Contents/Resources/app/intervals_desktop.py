#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import messagebox, ttk

import intervals_gui


class IntervalsDesktopApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Talaria")
        self.geometry("900x640")
        self.minsize(780, 520)

        self.config_data = intervals_gui.load_config()
        self.workouts = intervals_gui.workout_files()
        self.workout_vars: dict[str, tk.BooleanVar] = {}
        self.logo_image = None
        self.header_logo = None

        self._build_styles()
        self._load_logo()
        self._build_ui()

    def _load_logo(self) -> None:
        logo_path = intervals_gui.ROOT / "assets" / "talaria-logo.png"
        if not logo_path.exists():
            return
        try:
            self.logo_image = tk.PhotoImage(file=str(logo_path))
            self.iconphoto(True, self.logo_image)
            self.header_logo = self.logo_image.subsample(16, 16)
        except tk.TclError:
            self.logo_image = None
            self.header_logo = None

    def _build_styles(self) -> None:
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.configure(background="#f4f6f8")
        self.style.configure("TFrame", background="#f4f6f8")
        self.style.configure("Panel.TFrame", background="#ffffff")
        self.style.configure("TLabel", background="#f4f6f8", foreground="#1f2933")
        self.style.configure("Panel.TLabel", background="#ffffff", foreground="#20211f")
        self.style.configure("Muted.TLabel", foreground="#64748b")
        self.style.configure("TButton", padding=(11, 7), borderwidth=1)
        self.style.configure("Accent.TButton", padding=(11, 7), background="#176b5f", foreground="#ffffff")
        self.style.map("Accent.TButton", background=[("active", "#145b51")])
        self.style.configure("TNotebook", background="#f4f6f8", borderwidth=0)
        self.style.configure("TNotebook.Tab", padding=(14, 8), background="#e9eef3")
        self.style.map("TNotebook.Tab", background=[("selected", "#ffffff")])
        self.style.configure("TEntry", padding=(6, 5))
        self.style.configure("Vertical.TScrollbar", background="#d7dee6")

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=16)
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 14))
        if self.header_logo:
            ttk.Label(header, image=self.header_logo).pack(side="left", padx=(0, 10))
            text_header = ttk.Frame(header)
            text_header.pack(side="left", fill="x", expand=True)
        else:
            text_header = header
        ttk.Label(text_header, text="Talaria", font=("Helvetica", 20, "bold")).pack(anchor="w")
        ttk.Label(
            text_header,
            text="Upload workouts and copy completed-training context for your AI coach.",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(4, 0))
        ttk.Button(header, text="Open Web App", command=self.open_web_app).pack(side="right")

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True)

        self.setup_tab = ttk.Frame(notebook, padding=14)
        self.upload_tab = ttk.Frame(notebook, padding=14)
        self.progress_tab = ttk.Frame(notebook, padding=14)
        notebook.add(self.setup_tab, text="Setup")
        notebook.add(self.upload_tab, text="Upload Workouts")
        notebook.add(self.progress_tab, text="Progress Read")

        self._build_setup_tab()
        self._build_upload_tab()
        self._build_progress_tab()

    def _build_setup_tab(self) -> None:
        ttk.Label(self.setup_tab, text="Intervals.icu API key", font=("Helvetica", 14, "bold")).pack(anchor="w")
        ttk.Label(
            self.setup_tab,
            text="Paste your Intervals.icu API key. Athlete id can usually stay as 0.",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(4, 12))

        form = ttk.Frame(self.setup_tab)
        form.pack(fill="x", pady=(0, 12))

        ttk.Label(form, text="API key").grid(row=0, column=0, sticky="w", pady=(0, 6))
        self.api_key_var = tk.StringVar()
        api_entry = ttk.Entry(form, textvariable=self.api_key_var, show="*", width=48)
        api_entry.grid(row=1, column=0, sticky="ew", padx=(0, 12))
        api_entry.insert(0, "")

        ttk.Label(form, text="Athlete id").grid(row=0, column=1, sticky="w", pady=(0, 6))
        self.athlete_id_var = tk.StringVar(value=str(self.config_data.get("athlete_id") or "0"))
        ttk.Entry(form, textvariable=self.athlete_id_var, width=18).grid(row=1, column=1, sticky="ew")
        form.columnconfigure(0, weight=1)

        button_row = ttk.Frame(self.setup_tab)
        button_row.pack(fill="x", pady=(4, 12))
        ttk.Button(button_row, text="Save", command=self.save_config, style="Accent.TButton").pack(side="left")
        ttk.Button(button_row, text="Test key", command=self.test_key).pack(side="left", padx=(8, 0))

        saved = "Saved API key present." if self.config_data.get("api_key") else "No API key saved yet."
        self.setup_status = tk.StringVar(value=saved)
        ttk.Label(self.setup_tab, textvariable=self.setup_status, style="Muted.TLabel", wraplength=760).pack(anchor="w")

        note = (
            "Settings are stored in ~/Library/Application Support/Talaria. "
            "They stay saved when Talaria is moved to another folder."
        )
        ttk.Label(self.setup_tab, text=note, style="Muted.TLabel", wraplength=720).pack(anchor="w", pady=(20, 0))

    def _build_upload_tab(self) -> None:
        top = ttk.Frame(self.upload_tab)
        top.pack(fill="x", pady=(0, 12))
        self.workout_count_var = tk.StringVar(value=f"{len(self.workouts)} workouts found")
        ttk.Label(top, textvariable=self.workout_count_var, font=("Helvetica", 14, "bold")).pack(side="left")
        ttk.Button(top, text="Upload selected", command=self.upload_selected, style="Accent.TButton").pack(side="right")
        ttk.Button(top, text="Refresh", command=self.refresh_workouts).pack(side="right", padx=(0, 8))
        ttk.Button(top, text="Future only", command=self.select_future).pack(side="right", padx=(0, 8))
        ttk.Button(top, text="Select all", command=self.select_all).pack(side="right", padx=(0, 8))
        ttk.Button(top, text="Clear", command=self.clear_selection).pack(side="right", padx=(0, 8))

        container = ttk.Frame(self.upload_tab)
        container.pack(fill="both", expand=True)

        canvas = tk.Canvas(container, background="#ffffff", highlightthickness=1, highlightbackground="#d9e1e8")
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.workout_frame = ttk.Frame(canvas, padding=10)
        self.workout_frame.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.workout_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.render_workouts()

        self.upload_status = tk.StringVar(value="Ready.")
        ttk.Label(self.upload_tab, textvariable=self.upload_status, style="Muted.TLabel").pack(anchor="w", pady=(10, 0))

    def render_workouts(self) -> None:
        for child in self.workout_frame.winfo_children():
            child.destroy()
        self.workout_vars = {}
        for i, workout in enumerate(self.workouts):
            var = tk.BooleanVar(value=True)
            self.workout_vars[workout["id"]] = var
            text = f"{workout['date']}   {workout['type']}   {workout['name']}"
            ttk.Checkbutton(self.workout_frame, text=text, variable=var).grid(row=i, column=0, sticky="w", pady=2)
        self.workout_count_var.set(f"{len(self.workouts)} workouts found")

    def refresh_workouts(self) -> None:
        self.workouts = intervals_gui.workout_files()
        self.render_workouts()
        self.upload_status.set("Workout folder refreshed.")

    def _build_progress_tab(self) -> None:
        controls = ttk.Frame(self.progress_tab)
        controls.pack(fill="x", pady=(0, 12))

        today = intervals_gui.date.today()
        oldest = today - intervals_gui.timedelta(days=21)
        newest = today + intervals_gui.timedelta(days=7)

        ttk.Label(controls, text="Oldest").pack(side="left")
        self.oldest_var = tk.StringVar(value=oldest.isoformat())
        ttk.Entry(controls, textvariable=self.oldest_var, width=14).pack(side="left", padx=(6, 14))

        ttk.Label(controls, text="Newest").pack(side="left")
        self.newest_var = tk.StringVar(value=newest.isoformat())
        ttk.Entry(controls, textvariable=self.newest_var, width=14).pack(side="left", padx=(6, 14))

        ttk.Button(controls, text="Fetch summary", command=self.fetch_progress).pack(side="left")
        ttk.Button(controls, text="Copy", command=self.copy_summary).pack(side="left", padx=(8, 0))

        self.summary_text = tk.Text(
            self.progress_tab,
            wrap="word",
            height=22,
            padx=12,
            pady=12,
            background="#ffffff",
            foreground="#1f2933",
            insertbackground="#1f2933",
            relief="solid",
            borderwidth=1,
        )
        self.summary_text.pack(fill="both", expand=True)

        bottom_row = ttk.Frame(self.progress_tab)
        bottom_row.pack(fill="x", pady=(10, 0))
        self.progress_status = tk.StringVar(value="Ready.")
        ttk.Label(bottom_row, textvariable=self.progress_status, style="Muted.TLabel").pack(side="left", fill="x", expand=True)
        ttk.Button(bottom_row, text="View reports", command=self.view_reports).pack(side="right")

    def save_config(self) -> None:
        update = {"athlete_id": self.athlete_id_var.get().strip() or "0"}
        if self.api_key_var.get().strip():
            update["api_key"] = self.api_key_var.get().strip()
        intervals_gui.save_config(update)
        self.config_data = intervals_gui.load_config()
        self.api_key_var.set("")
        self.setup_status.set("Saved locally.")

    def run_background(self, status_var: tk.StringVar, loading: str, fn) -> None:
        status_var.set(loading)

        def worker() -> None:
            try:
                result = fn()
                self.after(0, lambda: status_var.set(result))
            except Exception as exc:
                self.after(0, lambda: status_var.set(f"Error: {exc}"))

        threading.Thread(target=worker, daemon=True).start()

    def test_key(self) -> None:
        self.save_config()

        def task() -> str:
            config = intervals_gui.load_config()
            athlete_id = config.get("athlete_id", "0") or "0"
            intervals_gui.intervals_request(
                "GET",
                f"/athlete/{athlete_id}/activities",
                config.get("api_key", ""),
                query={"oldest": intervals_gui.date.today().isoformat(), "newest": intervals_gui.date.today().isoformat()},
            )
            return "API key works. Activity read succeeded."

        self.run_background(self.setup_status, "Testing API key...", task)

    def select_all(self) -> None:
        for var in self.workout_vars.values():
            var.set(True)

    def clear_selection(self) -> None:
        for var in self.workout_vars.values():
            var.set(False)

    def select_future(self) -> None:
        today = intervals_gui.date.today().isoformat()
        for workout in self.workouts:
            self.workout_vars[workout["id"]].set(workout["date"] >= today)

    def upload_selected(self) -> None:
        selected = [workout_id for workout_id, var in self.workout_vars.items() if var.get()]
        if not selected:
            messagebox.showinfo("No workouts selected", "Select at least one workout first.")
            return

        def task() -> str:
            config = intervals_gui.load_config()
            athlete_id = config.get("athlete_id", "0") or "0"
            events = intervals_gui.selected_events(selected)
            response = intervals_gui.intervals_request(
                "POST",
                f"/athlete/{athlete_id}/events/bulk",
                config.get("api_key", ""),
                body=events,
                query={"upsert": "true"},
            )
            count = len(response) if isinstance(response, list) else len(events)
            return f"Uploaded or updated {count} planned workouts."

        self.run_background(self.upload_status, f"Uploading {len(selected)} workouts...", task)

    def fetch_progress(self) -> None:
        self.progress_status.set("Fetching Intervals.icu data...")

        def worker() -> None:
            try:
                config = intervals_gui.load_config()
                athlete_id = config.get("athlete_id", "0") or "0"
                api_key = config.get("api_key", "")
                oldest = self.oldest_var.get().strip()
                newest = self.newest_var.get().strip()
                params = {"oldest": oldest, "newest": newest}
                activities = intervals_gui.intervals_request("GET", f"/athlete/{athlete_id}/activities", api_key, query=params) or []
                events = []
                try:
                    wellness = intervals_gui.intervals_request("GET", f"/athlete/{athlete_id}/wellness", api_key, query=params) or []
                except Exception:
                    wellness = []
                activity_enrichment = intervals_gui.fetch_activity_enrichment(activities, api_key)
                fitness_events = intervals_gui.fetch_fitness_model_events(athlete_id, api_key)
                curve_context = intervals_gui.fetch_athlete_curve_context(athlete_id, api_key, oldest, newest)
                summary = intervals_gui.build_progress_summary(
                    activities,
                    events,
                    wellness,
                    oldest,
                    newest,
                    activity_enrichment=activity_enrichment,
                    fitness_events=fitness_events,
                    curve_context=curve_context,
                )
                result = {
                    "summary": summary,
                    "oldest": oldest,
                    "newest": newest,
                    "activity_count": len(activities),
                    "wellness_count": len(wellness),
                    "fitness_count": len(fitness_events),
                }
                self.after(0, lambda: self.handle_progress_result(result))
            except Exception as exc:
                self.after(0, lambda: self.progress_status.set(f"Error: {exc}"))

        threading.Thread(target=worker, daemon=True).start()

    def handle_progress_result(self, result: dict[str, object]) -> None:
        summary = str(result["summary"])
        self.set_summary(summary)
        activity_count = int(result["activity_count"])
        message = (
            f"Fetched {activity_count} activities, "
            f"{result['wellness_count']} wellness records, {result['fitness_count']} fitness/load events."
        )
        if activity_count > 25:
            should_save = messagebox.askyesno(
                "Save Markdown report?",
                (
                    f"Talaria fetched {activity_count} completed activities. "
                    "Do you want to also save the full summary as a Markdown file?"
                ),
            )
            if should_save:
                path = intervals_gui.save_markdown_report(summary, str(result["oldest"]), str(result["newest"]))
                message += f" Markdown report saved to {path}."
            else:
                message += " Markdown save skipped; the text summary is still shown here."
        self.progress_status.set(message)

    def set_summary(self, summary: str) -> None:
        self.summary_text.delete("1.0", "end")
        self.summary_text.insert("1.0", summary)

    def copy_summary(self) -> None:
        text = self.summary_text.get("1.0", "end").strip()
        self.clipboard_clear()
        self.clipboard_append(text)
        self.progress_status.set("Copied summary to clipboard.")

    def view_reports(self) -> None:
        path = intervals_gui.open_reports_folder()
        self.progress_status.set(f"Opened reports folder: {path}")

    def open_web_app(self) -> None:
        env = os.environ.copy()
        env["TALARIA_ROOT"] = str(intervals_gui.ROOT)
        env["TALARIA_OPEN_BROWSER"] = "1"
        log_path = intervals_gui.ROOT / "talaria-web.log"
        log_file = log_path.open("a", encoding="utf-8")
        subprocess.Popen(
            [sys.executable, str(intervals_gui.ROOT / "intervals_gui.py")],
            cwd=str(intervals_gui.ROOT),
            env=env,
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,
        )
        self.progress_status.set("Opening web app in your browser.")


if __name__ == "__main__":
    app = IntervalsDesktopApp()
    app.mainloop()
